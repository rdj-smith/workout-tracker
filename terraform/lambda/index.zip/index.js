
const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.TABLE_NAME || 'WorkoutLogs';

exports.handler = async (event) => {
    const method = event.requestContext.http.method;
    const body = event.body ? JSON.parse(event.body) : {};

    if (method === 'POST') {
        const item = {
            log_id: `${body.date}_${body.exercise}`,
            ...body
        };
        await db.put({ TableName: TABLE_NAME, Item: item }).promise();
        return { statusCode: 200, body: JSON.stringify({ message: 'Saved' }) };
    }

    if (method === 'GET') {
        const result = await db.scan({ TableName: TABLE_NAME }).promise();
        return { statusCode: 200, body: JSON.stringify(result.Items) };
    }

    return { statusCode: 400, body: 'Unsupported method' };
};
